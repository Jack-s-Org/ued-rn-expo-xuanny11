import SwipeDetector from "./SwipeDetector";

export default SwipeDetector;
